var map

function initialize(){
	map = new BMap.Map('bdmap');
	map.centerAndZoom(new BMap.Point(114.590658,30.652251),13);
	map.addControl(new BMap.MapTypeControl());
	map.setCurrentCity('武汉');
	map.enableScrollWheelZoom(true);
	//单击获取点击的经纬度
	// map.addEventListener('click',function(e){
	// 	alert(e.point.lng + ',' + e.point.lat);
	// });
	//添加定位的导航控件
    var navigationControl = new BMap.NavigationControl({
		anchor: BMAP_ANCHOR_TOP_LEFT,
		type: BMAP_NAVIGATION_CONTROL_LARGE,
		enableGeolocation: true
		});
    map.addControl(navigationControl);
	//切换城市类型
	var size = new BMap.Size(55, 20);
	map.addControl(new BMap.CityListControl({
		anchor: BMAP_ANCHOR_TOP_LEFT,
		offset: size,
		}))
	//全景
	var stCtrl = new BMap.PanoramaControl();
	stCtrl.setOffset(new BMap.Size(20, 50));
	map.addControl(stCtrl);
	//鹰眼
	var overCtrl = new BMap.OverviewMapControl();
	map.addControl(overCtrl);
	overCtrl.changeView();
	//个性化地图设置
	var sel=document.getElementById('stylelist');
	for (var key in mapstyles){
		var style=mapstyles[key];
		var item=new Option(style.title,key);
		sel.options.add(item);
	}
	changeMapStyle('normal')
	sel.value='normal'
	//输入框自动提示
	function G(id) {
		return document.getElementById(id);
	}
	//起点
	var ac = new BMap.Autocomplete(    //建立一个自动完成的对象
		{"input" : "tex_a"
		,"location" : map
	});
	
	ac.addEventListener("onhighlight", function(e) {  //鼠标放在下拉列表上的事件
		var str = "";
			var _value = e.fromitem.value;
			var value = "";
			if (e.fromitem.index > -1) {
				value = _value.province +  _value.city +  _value.district +  _value.street +  _value.business;
			}    
			str = "FromItem<br />index = " + e.fromitem.index + "<br />value = " + value;
			value = "";
			if (e.toitem.index > -1) {
				_value = e.toitem.value;
				value = _value.province +  _value.city +  _value.district +  _value.street +  _value.business;
			}    
			str += "<br />ToItem<br />index = " + e.toitem.index + "<br />value = " + value;
			G("searchResultPanel1").innerHTML = str;
	});

	var myValue;
	ac.addEventListener("onconfirm", function(e) {    //鼠标点击下拉列表后的事件
	var _value = e.item.value;
		myValue = _value.province +  _value.city +  _value.district +  _value.street +  _value.business;
		G("searchResultPanel1").innerHTML ="onconfirm<br />index = " + e.item.index + "<br />myValue = " + myValue;
		setPlace();
	});
	//终点
	var ab = new BMap.Autocomplete(    //建立一个自动完成的对象
		{"input" : "tex_b"
		,"location" : map
	});
	
	ab.addEventListener("onhighlight", function(e) {  //鼠标放在下拉列表上的事件
		var str = "";
			var _value = e.fromitem.value;
			var value = "";
			if (e.fromitem.index > -1) {
				value = _value.province +  _value.city +  _value.district +  _value.street +  _value.business;
			}    
			str = "FromItem<br />index = " + e.fromitem.index + "<br />value = " + value;
			value = "";
			if (e.toitem.index > -1) {
				_value = e.toitem.value;
				value = _value.province +  _value.city +  _value.district +  _value.street +  _value.business;
			}    
			str += "<br />ToItem<br />index = " + e.toitem.index + "<br />value = " + value;
			G("searchResultPanel1").innerHTML = str;
	});
	
	var myValue;
	ab.addEventListener("onconfirm", function(e) {    //鼠标点击下拉列表后的事件
	var _value = e.item.value;
		myValue = _value.province +  _value.city +  _value.district +  _value.street +  _value.business;
		G("searchResultPanel1").innerHTML ="onconfirm<br />index = " + e.item.index + "<br />myValue = " + myValue;
		setPlace();
	});
	
	function setPlace(){
		map.clearOverlays();    //清除地图上所有覆盖物
		function myFun(){
			var pp = local.getResults().getPoi(0).point;    //获取第一个智能搜索的结果
			map.centerAndZoom(pp, 18);
			map.addOverlay(new BMap.Marker(pp));    //添加标注
		}
		var local = new BMap.LocalSearch(map, { //智能搜索
		  onSearchComplete: myFun
		});
		local.search(myValue);
	}
}


function changeMapStyle(style){
	map.setMapStyle({style:style});
	$('#desc').html(mapstyles[style].desc);
}

function Walk(){
	map.clearOverlays();
	var a=document.getElementById('tex_a').value;
	var b=document.getElementById('tex_b').value;
	var walking = new BMap.WalkingRoute(map, {renderOptions: {map: map, panel: "r-result", autoViewport: true}});
	walking.search(a,b);
}

function Drive(){
	map.clearOverlays();
	var a=document.getElementById('tex_a').value;
	var b=document.getElementById('tex_b').value;
	var driving = new BMap.DrivingRoute(map, {renderOptions:{map: map, panel:'r-result',autoViewport: true}});
	driving.search(a,b);
}

function Bus(){
	map.clearOverlays();
	var a=document.getElementById('tex_a').value;
	var b=document.getElementById('tex_b').value;
	var transit = new BMap.TransitRoute(map, {renderOptions: {map: map, panel:'r-result',autoViewport: true}});
	transit.search(a,b)
}

var pri_info="<h4 style='margin:0 0 5px 0;padding:0.2em 0'>允张逸夫小学</h4>" + 
"<img style='float:right;margin:4px' src='./img/doge1.png' width='100' height='100' title='允张逸夫小学'/>" + 
"<p style='margin:0;line-height:1.5;font-size:13px;text-indent:2em'>小学，是人们接受初等正规教育的学校，是基础教育的重要组成部分...</p>"+"</div>";
var jr_info="<h4 style='margin:0 0 5px 0;padding:0.2em 0'>前进路中学</h4>" + 
"<img style='float:right;margin:4px' src='./img/doge1.png' width='100' height='100' title='前进路中学'/>" + 
"<p style='margin:0;line-height:1.5;font-size:13px;text-indent:2em'>初中是中学阶段的初级阶段，是向高级中学过渡的一个阶段，属于中等教育的范畴...</p>";
var high_info="<h4 style='margin:0 0 5px 0;padding:0.2em 0'>高新一中国际部</h4>" + 
"<img style='float:right;margin:4px' src='./img/doge1.png' width='100' height='100' title='高新一中国际部'/>" + 
"<p style='margin:0;line-height:1.5;font-size:13px;text-indent:2em'>高级中学的简称，我国中学分为初级中学与高级中学，两者同属中等教育的范畴...</p>";
var college_info="<h4 style='margin:0 0 5px 0;padding:0.2em 0'>湖北大学</h4>" + 
"<img style='float:right;margin:4px' src='./img/doge1.png' width='100' height='100' title='湖北大学'/>" + 
"<p style='margin:0;line-height:1.5;font-size:13px;text-indent:2em'>简称“湖大”，是中华人民共和国教育部与湖北省人民政府共建的省属重点综合性大学，位列湖北省“双一流”...</p>";

var opts = {
		width : 250,     // 信息窗口宽度
		height: 150,     // 信息窗口高度
		title : "信息窗口" , // 信息窗口标题
		enableMessage:true//设置允许信息窗发送短息
	};

//添加小学
function addPrimary(){
	map.clearOverlays();
	var point = new BMap.Point(109.497917,34.499829);
	map.centerAndZoom(point,18);
	var marker = new BMap.Marker(point);
	map.addOverlay(marker);
	var label = new BMap.Label('这是我的小学',{offset:new BMap.Size(20,-10)});
	marker.setLabel(label);
	marker.setAnimation(BMAP_ANIMATION_BOUNCE);
	addClickHandler(pri_info,marker);
	function addClickHandler(content,marker){
		marker.addEventListener("click",function(e){
			openInfo(content,e)}
		);
	}
	function openInfo(content,e){
		var p = e.target;
		var point = new BMap.Point(p.getPosition().lng, p.getPosition().lat);
		var infoWindow = new BMap.InfoWindow(content,opts);  // 创建信息窗口对象 
		map.openInfoWindow(infoWindow,point); //开启信息窗口
	}
}
//添加初中
function addJuniorMiddle(){
	map.clearOverlays();
	var point = new BMap.Point(109.497207,34.499487);
	map.centerAndZoom(point,18);
	var marker = new BMap.Marker(point);
	map.addOverlay(marker);
	var label = new BMap.Label('这是我的初中',{offset:new BMap.Size(20,-10)});
	marker.setLabel(label);
	marker.setAnimation(BMAP_ANIMATION_BOUNCE);
	addClickHandler(jr_info,marker);
	function addClickHandler(content,marker){
		marker.addEventListener("click",function(e){
			openInfo(content,e)}
		);
	}
	function openInfo(content,e){
		var p = e.target;
		var point = new BMap.Point(p.getPosition().lng, p.getPosition().lat);
		var infoWindow = new BMap.InfoWindow(content,opts);  // 创建信息窗口对象 
		map.openInfoWindow(infoWindow,point); //开启信息窗口
	}
}
//添加高中
function addHigh(){
	map.clearOverlays();
	var point = new BMap.Point(108.888727,34.184358);
	map.centerAndZoom(point,18);
	var marker = new BMap.Marker(point);
	map.addOverlay(marker);
	var label = new BMap.Label('这是我的高中',{offset:new BMap.Size(20,-10)});
	marker.setLabel(label);
	marker.setAnimation(BMAP_ANIMATION_BOUNCE);
	addClickHandler(high_info,marker);
	function addClickHandler(content,marker){
		marker.addEventListener("click",function(e){
			openInfo(content,e)}
		);
	}
	function openInfo(content,e){
		var p = e.target;
		var point = new BMap.Point(p.getPosition().lng, p.getPosition().lat);
		var infoWindow = new BMap.InfoWindow(content,opts);  // 创建信息窗口对象 
		map.openInfoWindow(infoWindow,point); //开启信息窗口
	}
}
//添加大学
function addCollege(){
	map.clearOverlays();
	var point = new BMap.Point(114.590658,30.652251);
	map.centerAndZoom(point,18);
	var marker = new BMap.Marker(point);
	map.addOverlay(marker);
	var label = new BMap.Label('这是我的大学',{offset:new BMap.Size(20,-10)});
	marker.setLabel(label);
	//echarts
	var sContent="<iframe width='450px' height='300px' frameborder='no' border='0' marginwidth='0' marginheight='0' src='echarts弹窗.html'/>";
	var infoWindow=new BMap.InfoWindow(sContent);
	marker.addEventListener('click',function(){
		this.openInfoWindow(infoWindow);
	});
	// marker.setAnimation(BMAP_ANIMATION_BOUNCE);
	// addClickHandler(college_info,marker);
	// function addClickHandler(content,marker){
	// 	marker.addEventListener("click",function(e){
	// 		openInfo(content,e)}
	// 	);
	// }
	// function openInfo(content,e){
	// 	var p = e.target;
	// 	var point = new BMap.Point(p.getPosition().lng, p.getPosition().lat);
	// 	var infoWindow = new BMap.InfoWindow(content,opts);  // 创建信息窗口对象 
	// 	map.openInfoWindow(infoWindow,point); //开启信息窗口
	// }
}
//显示所有
function showAll(){
	map.clearOverlays();
		var data=[
		[109.497917,34.499829,'小学',pri_info],
		[109.497207,34.499487,'初中',jr_info],
		[108.888727,34.184358,'高中',high_info],
		[114.590658,30.652251,'大学',college_info]
	];
	for (var i=0;i<data.length;i++){
		var point= new BMap.Point(data[i][0],data[i][1]);
		var marker= new BMap.Marker(point);
		map.addOverlay(marker);
		content=data[i][2]
		var label= new BMap.Label(content,{offset:new BMap.Size(20,-10)});
		marker.setLabel(label);
		addClickHandler(data[i][3],marker);
	};
	function addClickHandler(content,marker){
		marker.addEventListener("click",function(e){
			openInfo(content,e)}
		);
	}
	function openInfo(content,e){
		var p = e.target;
		var point = new BMap.Point(p.getPosition().lng, p.getPosition().lat);
		var infoWindow = new BMap.InfoWindow(content,opts);  // 创建信息窗口对象 
		map.openInfoWindow(infoWindow,point); //开启信息窗口
	}
	var point0 = new BMap.Point(108.888727,34.184358);
	map.centerAndZoom(point0,5);
}

function polyline(){
	map.clearOverlays();
	var sy = new BMap.Symbol(BMap_Symbol_SHAPE_BACKWARD_OPEN_ARROW,{
		scale:0.6,
		strokeColor:'#fff',
		strokeWeight:'2',
	});
	var icons= new BMap.IconSequence(sy,'100','30');
	var pois=[
		new BMap.Point(109.497917,34.499829),
		new BMap.Point(109.497207,34.499487),
		new BMap.Point(108.888727,34.184358),
		new BMap.Point(114.590658,30.652251)
	];
	var polyline = new BMap.Polyline(pois,{
		enableEditing:false,
		enableClicking:true,
		icons:[icons],
		strokeWeight:'8',
		strokeOpacity:0.8,
		strokeColor:'blue',
	})
	map.addOverlay(polyline);
	var point0 = new BMap.Point(108.888727,34.184358);
	map.centerAndZoom(point0,5);
}

function curve(){
	map.clearOverlays();
	var points=[
		new BMap.Point(109.497917,34.499829),
		new BMap.Point(109.497207,34.499487),
		new BMap.Point(108.888727,34.184358),
		new BMap.Point(114.590658,30.652251)
	];
	var curve=new BMapLib.CurveLine(points,{
		strokeColor:'red',
		strokeWeight:3,
		strokeOpacity:0.5
	});
	map.addOverlay(curve);
	curve.enableEditing();
	var point0 = new BMap.Point(108.888727,34.184358);
	map.centerAndZoom(point0,5);
}

function postgraduate(){
	map.clearOverlays();
	var points=[
		new BMap.Point(126.641267,45.753427),//哈工大
		new BMap.Point(113.304999,23.102849),//中山大学
		new BMap.Point(87.626829,43.771224),//新疆大学
		new BMap.Point(108.990148,34.252314),//西安交通大学
		new BMap.Point(121.443296,31.031963)//上海交通大学
	];
	var data_info = [
		[points[0],'哈工大','red'],
		[points[1],'中大','blue'],
		[points[2],'新疆大学','orange'],
		[points[3],'西交','purple'],
		[points[4],'上交','pink']
	];
	for (var i=0;i<data_info.length;i++){
		var point=data_info[i][0];
		var marker=new BMap.Marker(point);
		map.addOverlay(marker);
		content=data_info[i][1]
		var label= new BMap.Label(content,{offset:new BMap.Size(20,-10)});
		marker.setLabel(label);
		fro_to=[new BMap.Point(114.590658,30.652251),point]
		var curve=new BMapLib.CurveLine(fro_to,{
			strokeColor:data_info[i][2],
			strokeWeight:3,
			strokeOpacity:0.5
		});
		map.addOverlay(curve);
		curve.enableEditing();
		luShu(new BMap.Point(114.590658,30.652251),point)
	};
	var point0 = new BMap.Point(108.888727,34.184358);
	map.centerAndZoom(point0,5);
}

function zoom_out(){
	var point0 = new BMap.Point(108.888727,34.184358);
	map.centerAndZoom(point0,5);
}

function luShu(start_point,end_point){
	var lushu;
	// 实例化一个驾车导航用来生成路线
    var drv = new BMap.DrivingRoute('北京', {
        onSearchComplete: function(res) {
            if (drv.getStatus() == BMAP_STATUS_SUCCESS) {
                var plan = res.getPlan(0);
                var arrPois =[];
                for(var j=0;j<plan.getNumRoutes();j++){
                    var route = plan.getRoute(j);
                    arrPois= arrPois.concat(route.getPath());
                }
                map.addOverlay(new BMap.Polyline(arrPois, {strokeColor: '#111'}));
                map.setViewport(arrPois);

                lushu = new BMapLib.LuShu(map,arrPois,{
                defaultContent:"",//"从天安门到百度大厦"
                autoView:true,//是否开启自动视野调整，如果开启那么路书在运动过程中会根据视野自动调整
                icon  : new BMap.Icon('./img/doge1.png', new BMap.Size(50,50),{anchor : new BMap.Size(27, 13)}),
                speed: 90000,
                enableRotation:false,//是否设置marker随着道路的走向进行旋转
                });
				lushu.start();
				zoom_out();
            }
        }
    });
    var start=start_point;
    var end=end_point;
	drv.search(start, end);
}

function HbuData(){
	var myChart=echarts.init(document.getElementById('hbuEcharts'));
	var opt={
		title:{
			text:'湖北大学概况'
		},
		tooltip:{},
		legend:{
			data:['数量']
		},
		xAxis:{
			data:['本科生','研究生','专任教师']
		},
		yAxis:{},
		series:[{
			name:'数据量',
			type:'bar',
			data:[12000,4600,2200],
			itemStyle:{}
		}]
	};
	myChart.setOption(opt);
}